package io.javabrains.ratingdataservice.resource;

import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.javabrains.ratingdataservice.model.Rating;

@RestController
@RequestMapping("/ratingsdata")
public class RatingResource {

	
	
	@GetMapping("/{movieId}")
	public Rating getMovieRatingData( @PathVariable("movieId")String movieId)
	{
		return new Rating(movieId, 4);
		
	}
}
