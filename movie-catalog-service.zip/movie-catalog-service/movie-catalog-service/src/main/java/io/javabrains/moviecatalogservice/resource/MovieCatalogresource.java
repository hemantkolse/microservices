package io.javabrains.moviecatalogservice.resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.javabrains.moviecatalogservice.model.Movie;
import io.javabrains.moviecatalogservice.model.MovieCatalog;
import io.javabrains.moviecatalogservice.model.Rating;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogresource {

	
	@Autowired
	RestTemplate resttemplate;
	
	
	@RequestMapping("/{userId}")
	public List<MovieCatalog> getMovieCatalogForUser(@PathVariable("userId")String userId)
	{
		// get all rated movie id
		
		List<Rating> ratings=Arrays.asList(
				new Rating("1234", 4),
				new Rating("5678",5)
				);
	
		List<MovieCatalog> moviecatalog=new ArrayList<>();
		for(Rating rating:ratings)
		{
			// for each movie ID,call movie info service and get details
			
		Movie movie=resttemplate.getForObject("movie-info-service/movies/"+rating.getMovieId(), Movie.class);
		
		//put them all together
		moviecatalog.add(new MovieCatalog(movie.getName(),movie.getDesc(),rating.getRating()));
	
			
		};
		
		return moviecatalog;
		
		
		
	}
}
